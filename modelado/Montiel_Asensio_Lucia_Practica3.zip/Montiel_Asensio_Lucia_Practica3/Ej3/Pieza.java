package Ej3;

public class Pieza {
}
