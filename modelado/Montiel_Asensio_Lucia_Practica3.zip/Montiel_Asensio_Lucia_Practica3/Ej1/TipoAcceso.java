package Ej1;

public enum TipoAcceso {

    consulta, modificacion, creacion, archivo;
}
